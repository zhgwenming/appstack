package p1

func F() int { return 1 }
