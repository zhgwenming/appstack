package p2

func F() int { return 1 }
