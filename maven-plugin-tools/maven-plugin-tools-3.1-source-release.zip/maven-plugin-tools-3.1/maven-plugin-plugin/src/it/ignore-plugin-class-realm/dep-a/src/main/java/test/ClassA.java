package test;

public class ClassA
{
}
