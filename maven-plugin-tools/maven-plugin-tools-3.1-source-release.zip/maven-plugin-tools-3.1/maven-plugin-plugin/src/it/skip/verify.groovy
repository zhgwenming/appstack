File descriptorFile = new File( basedir, "target/classes/META-INF/maven/plugin.xml" );
assert !descriptorFile.isFile()

return true;
