package test;

// NOTE: This source file is by design encoded using UTF-8!

import org.apache.maven.plugin.AbstractMojo;

/**
 * TEST-CHARS: ßıΣЯא€
 * 
 * @goal test
 */
public class MyMojo
    extends AbstractMojo
{

    public void execute()
    {
    }

}
