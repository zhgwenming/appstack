package test;

// NOTE: This source file is by design encoded using ISO-8859-1!

import org.apache.maven.plugin.AbstractMojo;

/**
 * TEST-CHARS: �������
 * 
 * @goal test
 */
public class MyMojo
    extends AbstractMojo
{

    public void execute()
    {
    }

}
