package test;

import org.apache.maven.plugin.AbstractMojo;

/**
 * MOJO-DESCRIPTION.
 * 
 * @goal test
 */
public class MyMojo
    extends AbstractMojo
{

    public void execute()
    {
    }

}
