/**
 * Regression test for MPLUGIN-39.
 */
package source;
