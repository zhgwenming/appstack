public class JavaHello implements Helloable {
	public void sayHello() {
		System.out.println("Hello World from Java!");
	}
}