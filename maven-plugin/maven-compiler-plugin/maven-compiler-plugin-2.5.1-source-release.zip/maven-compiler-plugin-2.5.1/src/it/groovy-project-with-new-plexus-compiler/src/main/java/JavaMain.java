public class JavaMain {
	public static void main(String... args) {
		new GroovyHello().sayHello();
		new JavaHello().sayHello();
	}
}