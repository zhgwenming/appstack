package org.apache.maven.plugins.compiler.it;

/**
 * Hello world!
 *
 */
public class App2
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public static void mainFoo( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public void bar( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public void foo( String[] args )
    {
        System.out.println( "Hello World!" );
    }

    public void barfoo( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
