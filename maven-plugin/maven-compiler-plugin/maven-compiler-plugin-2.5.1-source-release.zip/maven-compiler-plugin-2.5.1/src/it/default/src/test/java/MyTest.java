import junit.framework.TestCase;

public class MyTest
    extends TestCase
{

}
