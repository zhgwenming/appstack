package org.codehaus.foo;

public class Bad
{
    // Intentionally misspelled modifier.
    pubic String name;
}
