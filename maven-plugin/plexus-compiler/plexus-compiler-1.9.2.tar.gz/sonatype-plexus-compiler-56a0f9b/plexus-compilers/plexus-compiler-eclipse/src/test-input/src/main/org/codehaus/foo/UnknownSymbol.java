package org.codehaus.foo;

public class UnknownSymbol
{
    public UnknownSymbol()
    {
        foo();
    }
}
