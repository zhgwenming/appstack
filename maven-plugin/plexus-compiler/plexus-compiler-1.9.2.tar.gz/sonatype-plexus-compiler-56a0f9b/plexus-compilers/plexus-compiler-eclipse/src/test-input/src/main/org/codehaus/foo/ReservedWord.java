package org.codehaus.foo;

public class ReservedWord
{
	String assert;
}
