package org.codehaus.foo;

public class RightClassname
{
}
