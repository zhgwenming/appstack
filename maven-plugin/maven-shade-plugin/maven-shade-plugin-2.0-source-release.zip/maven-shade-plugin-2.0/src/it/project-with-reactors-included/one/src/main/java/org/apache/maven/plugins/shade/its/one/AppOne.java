package org.apache.maven.plugins.shade.its.one;

/**
 * Hello world!
 *
 */
public class AppOne
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
