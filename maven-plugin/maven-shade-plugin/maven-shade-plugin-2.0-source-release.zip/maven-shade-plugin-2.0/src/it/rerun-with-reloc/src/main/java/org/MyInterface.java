package org;

/*
 * NOTE: The project's main artifact must not be empty!
 */
public interface MyInterface
{
}
