package org.apache.maven.it.pi;
public class Main extends HaveOneClass
{
}
