public class Main
    extends junit.framework.TestCase
{
}
