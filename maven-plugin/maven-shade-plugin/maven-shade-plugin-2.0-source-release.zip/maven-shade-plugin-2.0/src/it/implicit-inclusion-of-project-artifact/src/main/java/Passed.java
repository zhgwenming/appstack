public class Passed
{
}
