package org.codehaus.plexus.archiver;

import java.util.List;


/**
 * @deprecated Use {@link FileSelector file selectors}.
 */
public interface FilterEnabled
{
    
    void setArchiveFilters( List filters );

}
