package abstractClasses;

import junit.framework.TestCase;

public abstract class NonInstantiableTest
    extends TestCase
{

}
