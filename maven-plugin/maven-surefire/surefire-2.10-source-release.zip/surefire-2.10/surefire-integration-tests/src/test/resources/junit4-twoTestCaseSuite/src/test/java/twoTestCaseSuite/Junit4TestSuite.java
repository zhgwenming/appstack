package twoTestCaseSuite;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    BasicTest.class,
    Junit4TestTwo.class
})
public class Junit4TestSuite
{
    
}
