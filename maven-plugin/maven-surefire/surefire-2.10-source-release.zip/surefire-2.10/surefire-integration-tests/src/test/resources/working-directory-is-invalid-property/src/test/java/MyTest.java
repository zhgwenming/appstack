import junit.framework.TestCase;

public class MyTest extends TestCase {
    public void testSomething() {
        assertTrue(true);
    }
}
