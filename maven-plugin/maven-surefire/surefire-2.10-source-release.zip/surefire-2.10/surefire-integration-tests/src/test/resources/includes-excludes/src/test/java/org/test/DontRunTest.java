package org.test;

import junit.framework.TestCase;

public class DontRunTest extends TestCase
{
    public void testRun()
    {
        assertEquals(true, false);
    }
}
