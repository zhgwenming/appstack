package testng.simple;

import org.testng.annotations.Test;


public class TestNGSuiteTest {

	@Test
	public void doNothing()
	{
		
	}
}