package surefire257;
public class MyModule1Class {
  public int getFoo() {
    return 42;
  }
}
