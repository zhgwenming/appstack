package junit.runOrder;
import junit.framework.TestCase;


public class TestB
    extends TestCase
{
    public void testTwo() {
        System.out.println("TB");
    }
}
