package twoTestCaseSuite;

import org.junit.Test;

public class Junit4TestTwo
{
    @Test public void secondTest() {}
}
