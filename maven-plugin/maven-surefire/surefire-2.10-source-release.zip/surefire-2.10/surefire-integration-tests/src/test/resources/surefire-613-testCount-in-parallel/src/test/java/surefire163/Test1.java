package surefire613;

import org.junit.Test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assume.*;
public class Test1
{
    @Test
    public void testWithFailingAssumption1() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption2() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption3() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption4() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption5() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption6() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption7() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption8() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption9() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption10() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption11() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption12() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption13() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption14() {
        assumeThat( 2, is(3));
    }
    @Test
    public void testWithFailingAssumption15() {
        assumeThat( 2, is(3));
    }
}