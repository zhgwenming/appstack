package junit.notExtendingTestCase;
public class TestHelper {
    public TestHelper(String two, String arguments) {} 
}