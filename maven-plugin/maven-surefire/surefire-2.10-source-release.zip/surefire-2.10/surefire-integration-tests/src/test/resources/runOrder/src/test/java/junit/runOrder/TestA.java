package junit.runOrder;
import junit.framework.TestCase;


public class TestA
    extends TestCase
{
    public void testTwo() {
        System.out.println("TA");
    }
}
