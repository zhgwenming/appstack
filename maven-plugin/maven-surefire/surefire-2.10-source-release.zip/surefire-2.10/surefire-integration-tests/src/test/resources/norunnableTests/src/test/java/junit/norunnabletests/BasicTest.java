package junit.norunnabletests;

import junit.framework.TestCase;


public class BasicTest extends TestCase
{
}
