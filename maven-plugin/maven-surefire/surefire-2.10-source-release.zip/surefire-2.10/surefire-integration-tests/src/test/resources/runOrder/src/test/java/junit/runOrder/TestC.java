package junit.runOrder;
import junit.framework.TestCase;


public class TestC
    extends TestCase
{
    public void testTwo() {
        System.out.println("TC");
    }
}
