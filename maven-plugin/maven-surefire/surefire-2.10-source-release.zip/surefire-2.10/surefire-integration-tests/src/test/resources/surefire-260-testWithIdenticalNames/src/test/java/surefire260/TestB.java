package surefire260;
import junit.framework.TestCase;


public class TestB
    extends TestCase
{
    public void testDup() {
        fail("This is what we want");
    }
}
