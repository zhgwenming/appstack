package testng.two;

import org.testng.annotations.Test;


public class TestNGTestTwo {

	@Test
	public void testTwo()
	{
		
	}
}