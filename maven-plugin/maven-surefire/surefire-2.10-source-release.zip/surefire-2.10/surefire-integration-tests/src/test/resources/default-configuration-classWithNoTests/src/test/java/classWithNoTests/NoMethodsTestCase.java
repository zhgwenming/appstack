package classWithNoTests;

public class NoMethodsTestCase {}