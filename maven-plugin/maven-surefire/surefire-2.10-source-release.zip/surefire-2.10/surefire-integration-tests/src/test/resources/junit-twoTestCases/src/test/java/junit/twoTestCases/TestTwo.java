package junit.twoTestCases;
import junit.framework.TestCase;


public class TestTwo
    extends TestCase
{
    public void testTwo() {}
}
