package surefire500;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class PassingTest {
	
	@Test
	public void testOne()
    {
		assertTrue(true);
	}
	
	@Test
	public void testTwo()
    {
		assertTrue(true);
	}
	
	@Test
	public void testThree()
    {
		assertTrue(true);
	}
	
	@Test
	public void testFour()
    {
		assertTrue(true);
	}

}
