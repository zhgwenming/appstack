package surefire260;
import junit.framework.TestCase;


public class TestC
    extends TestCase
{
    public void testDup() {
        fail("This is what we want");
    }
}
