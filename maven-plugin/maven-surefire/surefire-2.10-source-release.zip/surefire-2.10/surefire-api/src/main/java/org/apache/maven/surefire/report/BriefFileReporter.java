package org.apache.maven.surefire.report;

/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

import java.io.File;

/**
 * Brief format file reporter.
 *
 * @author <a href="mailto:jruiz@exist.com">Johnny R. Ruiz III</a>
 * @version $Id: BriefFileReporter.java 1143207 2011-07-05 21:37:57Z pgier $
 */
public class BriefFileReporter
    extends AbstractFileReporter
{

    public BriefFileReporter( boolean trimStackTrace, File reportsDirectory )
    {
        super( trimStackTrace, BRIEF, reportsDirectory );
    }
    
    public BriefFileReporter( boolean trimStackTrace, File reportsDirectory, String reportNameSuffix )
    {
        super( trimStackTrace, BRIEF, reportsDirectory, reportNameSuffix );
    }
}
