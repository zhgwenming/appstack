

public class TestCompile1
{

    public TestCompile1()
    {

        System.out.println("Woo Hoo!");
    }

}