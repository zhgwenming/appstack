This file is junk and should not be picked up as a descriptor.
