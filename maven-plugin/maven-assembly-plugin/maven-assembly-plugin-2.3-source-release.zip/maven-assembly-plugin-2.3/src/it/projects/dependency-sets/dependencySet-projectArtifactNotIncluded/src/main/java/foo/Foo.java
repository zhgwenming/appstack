package foo;

public class Foo {
	public static void main(String[] args) {
		System.out.println("Hello, World!");
	}
}